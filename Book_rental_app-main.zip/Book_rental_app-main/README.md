# BookCave
Android app to sell and rent books in a city. Done as a project for MCA Sem-I

it's still WORK IN PROGRESS.
